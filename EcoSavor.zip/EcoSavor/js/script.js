//Toggle active class
const navbarNav = document.querySelector('.navbar-nav');
//ketika humenu di klik
document.querySelector('#humenu').onclick = () => {
    navbarNav.classList.toggle('active');
};

// Klik di luar menu untuk menghilangkan nav
const humburger = document.querySelector('humenu');
document.addEventListener('click', function(e){
    if(!humenu.contains(e.target) && !navbarNav.contains(e.target)){
        navbarNav.classList.remove('active');
    }
});
